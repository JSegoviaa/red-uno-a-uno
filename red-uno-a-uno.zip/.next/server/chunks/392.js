"use strict";
exports.id = 392;
exports.ids = [392];
exports.modules = {

/***/ 1392:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "X": () => (/* binding */ MapContext),
/* harmony export */   "I": () => (/* binding */ MapProvider)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


const MapContext = /*#__PURE__*/ (0,react__WEBPACK_IMPORTED_MODULE_1__.createContext)({
});
const MapProvider = ({ children  })=>{
    const { 0: coordenadas , 1: setCoordenadas  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)({
        lat: 19.4326077,
        lng: -99.133208
    });
    const { 0: ubicacion , 1: setUbicacion  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)({
        lat: 19.4326077,
        lng: -99.133208
    });
    const { 0: direccion , 1: setDireccion  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)();
    const { 0: dirMapa , 1: setDirMapa  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("Ciudad de M\xe9xico, CDMX, M\xe9xico");
    const { 0: zoom , 1: setZoom  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(5);
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(MapContext.Provider, {
        value: {
            coordenadas,
            setCoordenadas,
            ubicacion,
            setUbicacion,
            direccion,
            setDireccion,
            dirMapa,
            setDirMapa,
            zoom,
            setZoom
        },
        children: children
    }));
};


/***/ })

};
;