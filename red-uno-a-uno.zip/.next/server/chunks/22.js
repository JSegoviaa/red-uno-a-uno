"use strict";
exports.id = 22;
exports.ids = [22];
exports.modules = {

/***/ 6681:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "C": () => (/* binding */ production)
/* harmony export */ });
/* unused harmony export development */
const production = "https://prueba-red1a1.herokuapp.com/api";
const development = "http://localhost:8080/api";


/***/ }),

/***/ 22:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "L8": () => (/* binding */ fetchSinToken),
/* harmony export */   "u9": () => (/* binding */ googleLogin),
/* harmony export */   "bf": () => (/* binding */ crearUsuarioFetch),
/* harmony export */   "Z_": () => (/* binding */ fetchConToken),
/* harmony export */   "lI": () => (/* binding */ fetchContactForm),
/* harmony export */   "oi": () => (/* binding */ fetchInmueble),
/* harmony export */   "dW": () => (/* binding */ fetchActualizarInmueble),
/* harmony export */   "iE": () => (/* binding */ fetchBorrarInmueble),
/* harmony export */   "P5": () => (/* binding */ actualizarPerfilFetch),
/* harmony export */   "uW": () => (/* binding */ actualizarRolUsuario),
/* harmony export */   "o4": () => (/* binding */ agregarFav),
/* harmony export */   "Ie": () => (/* binding */ eliminarFavorito),
/* harmony export */   "Fl": () => (/* binding */ agregarHist),
/* harmony export */   "I": () => (/* binding */ eliminarHist),
/* harmony export */   "ec": () => (/* binding */ subirFotoPerfil),
/* harmony export */   "Fy": () => (/* binding */ subirFotosInmueble),
/* harmony export */   "Xo": () => (/* binding */ obtenerMensajes),
/* harmony export */   "kP": () => (/* binding */ crearChat),
/* harmony export */   "tU": () => (/* binding */ anadirPaqueteInv)
/* harmony export */ });
/* unused harmony exports enviarNuevoMensaje, agregarUsuario */
/* harmony import */ var _credentials_credentials__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6681);

const baseURL = _credentials_credentials__WEBPACK_IMPORTED_MODULE_0__/* .production */ .C;
const devURL = (/* unused pure expression or super */ null && (development));
const fetchSinToken = async (endpoint, data, method = "GET")=>{
    const url = `${baseURL}/${endpoint}`;
    if (method === "GET") {
        const resp = await fetch(url);
        return await resp.json();
    } else {
        const resp = await fetch(url, {
            method,
            headers: {
                "Content-type": "application/json"
            },
            body: JSON.stringify(data)
        });
        return await resp.json();
    }
};
const googleLogin = async (endpoint, body)=>{
    const url = `${baseURL}/${endpoint}`;
    const res = await fetch(url, {
        method: "POST",
        headers: {
            "Content-type": "application/json"
        },
        body: JSON.stringify(body)
    });
    const data = await res.json();
    return data;
};
const crearUsuarioFetch = async (endpoint, data)=>{
    const url = `${baseURL}/${endpoint}`;
    const resp = await fetch(url, {
        method: "POST",
        headers: {
            "Content-type": "application/json"
        },
        body: JSON.stringify(data)
    });
    return await resp.json();
};
const fetchConToken = async (endpoint, data, method = "GET")=>{
    const url = `${baseURL}/${endpoint}`;
    const token = localStorage.getItem("token") || "";
    if (method === "GET") {
        const resp = await fetch(url, {
            headers: {
                "x-token": token
            }
        });
        return await resp.json();
    } else {
        const resp = await fetch(url, {
            method,
            headers: {
                "Content-type": "application/json",
                "x-token": token
            },
            body: JSON.stringify(data)
        });
        return await resp.json();
    }
};
const fetchContactForm = async (endpoint, data)=>{
    const url = `${baseURL}/${endpoint}`;
    const resp = await fetch(url, {
        method: "POST",
        headers: {
            "Content-type": "application/json"
        },
        body: JSON.stringify(data)
    });
    return await resp.json();
};
const fetchInmueble = async (endpoint, data)=>{
    const url = `${baseURL}/${endpoint}`;
    const token = localStorage.getItem("token") || "";
    const resp = await fetch(url, {
        method: "POST",
        headers: {
            "Content-type": "application/json",
            "x-token": token
        },
        body: JSON.stringify(data)
    });
    return await resp.json();
};
const fetchActualizarInmueble = async (endpoint, data)=>{
    const url = `${baseURL}/${endpoint}`;
    const token = localStorage.getItem("token") || "";
    const resp = await fetch(url, {
        method: "PUT",
        headers: {
            "Content-type": "application/json",
            "x-token": token
        },
        body: JSON.stringify(data)
    });
    return await resp.json();
};
const fetchBorrarInmueble = async (endpoint, method = "DELETE")=>{
    const url = `${baseURL}/${endpoint}`;
    const token = localStorage.getItem("token") || "";
    const resp = await fetch(url, {
        method,
        headers: {
            "Content-type": "application/json",
            "x-token": token
        }
    });
    return await resp.json();
};
const actualizarPerfilFetch = async (endpoint, data)=>{
    const url = `${baseURL}/${endpoint}`;
    const token = localStorage.getItem("token") || "";
    const resp = await fetch(url, {
        method: "PUT",
        headers: {
            "Content-type": "application/json",
            "x-token": token
        },
        body: JSON.stringify(data)
    });
    return await resp.json();
};
const actualizarRolUsuario = async (endpoint, data)=>{
    const url = `${baseURL}/${endpoint}`;
    const token = localStorage.getItem("token") || "";
    const resp = await fetch(url, {
        method: "PUT",
        headers: {
            "Content-type": "application/json",
            "x-token": token
        },
        body: JSON.stringify(data)
    });
    return await resp.json();
};
const agregarFav = async (endpoint, data)=>{
    const url = `${baseURL}/${endpoint}`;
    const token = localStorage.getItem("token") || "";
    const res = await fetch(url, {
        method: "POST",
        headers: {
            "Content-type": "application/json",
            "x-token": token
        },
        body: JSON.stringify(data)
    });
    return await res.json();
};
const eliminarFavorito = async (endpoint)=>{
    const url = `${baseURL}/${endpoint}`;
    const token = localStorage.getItem("token") || "";
    const res = await fetch(url, {
        method: "DELETE",
        headers: {
            "Content-type": "application/json",
            "x-token": token
        }
    });
    return await res.json();
};
const agregarHist = async (endpoint, data)=>{
    const url = `${baseURL}/${endpoint}`;
    const token = localStorage.getItem("token") || "";
    const res = await fetch(url, {
        method: "POST",
        headers: {
            "Content-type": "application/json",
            "x-token": token
        },
        body: JSON.stringify(data)
    });
    return await res.json();
};
const eliminarHist = async (endpoint)=>{
    const url = `${baseURL}/${endpoint}`;
    const token = localStorage.getItem("token") || "";
    const res = await fetch(url, {
        method: "DELETE",
        headers: {
            "Content-type": "application/json",
            "x-token": token
        }
    });
    return await res.json();
};
const subirFotoPerfil = async (endpoint, data)=>{
    const url = `${baseURL}/${endpoint}`;
    const token = localStorage.getItem("token") || "";
    const resp = await fetch(url, {
        method: "POST",
        headers: {
            "x-token": token
        },
        body: data
    });
    return await resp.json();
};
const subirFotosInmueble = async (endpoint, data)=>{
    const url = `${baseURL}/${endpoint}`;
    const token = localStorage.getItem("token") || "";
    const resp = await fetch(url, {
        method: "POST",
        headers: {
            "x-token": token
        },
        body: data
    });
    return await resp.json();
};
const enviarNuevoMensaje = async (endpoint, data)=>{
    const url = `${baseURL}/${endpoint}`;
    const token = localStorage.getItem("token") || "";
    const resp = await fetch(url, {
        method: "POST",
        headers: {
            "Content-type": "application/json",
            "x-token": token
        },
        body: JSON.stringify(data)
    });
    return await resp.json();
};
const obtenerMensajes = async (endpoint)=>{
    const url = `${baseURL}/${endpoint}`;
    const token = localStorage.getItem("token") || "";
    const resp = await fetch(url, {
        headers: {
            "x-token": token
        }
    });
    return await resp.json();
};
const crearChat = async (endpoint, data)=>{
    const url = `${baseURL}/${endpoint}`;
    const token = localStorage.getItem("token") || "";
    const resp = await fetch(url, {
        method: "POST",
        headers: {
            "Content-type": "application/json",
            "x-token": token
        },
        body: JSON.stringify(data)
    });
    return await resp.json();
};
const anadirPaqueteInv = async (endpoint, data)=>{
    const url = `${baseURL}/${endpoint}`;
    const token = localStorage.getItem("token") || "";
    const resp = await fetch(url, {
        method: "POST",
        headers: {
            "Content-type": "application/json",
            "x-token": token
        },
        body: JSON.stringify(data)
    });
    return await resp.json();
};
const agregarUsuario = async (endpoint, data)=>{
    const url = `${devURL}/${endpoint}`;
    const token = localStorage.getItem("token") || "";
    const resp = await fetch(url, {
        method: "POST",
        headers: {
            "Content-type": "application/json",
            "x-token": token
        },
        body: JSON.stringify(data)
    });
    return await resp.json();
};


/***/ })

};
;