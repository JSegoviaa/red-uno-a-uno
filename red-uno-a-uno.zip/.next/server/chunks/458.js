"use strict";
exports.id = 458;
exports.ids = [458];
exports.modules = {

/***/ 1458:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "p5": () => (/* binding */ ChatContext),
  "aM": () => (/* binding */ ChatProvider)
});

// UNUSED EXPORTS: initialState

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./src/helpers/fetch.tsx
var fetch = __webpack_require__(22);
;// CONCATENATED MODULE: ./src/context/chat/chatReducer.tsx
const chatReducer = (state, action)=>{
    switch(action.type){
        case "ActivarChat":
            if (state.chatActivo === action.payload) return state;
            return {
                ...state,
                chatActivo: action.payload,
                mensajes: []
            };
        case "DesactivarChat":
            return {
                ...state,
                chatActivo: null,
                mensajes: []
            };
        case "NuevoMensaje":
            if (state.chatActivo === action.payload.remitente || state.chatActivo === action.payload.para) {
                return {
                    ...state,
                    mensajes: [
                        ...state.mensajes,
                        action.payload
                    ]
                };
            } else {
                return state;
            }
        case "CargarMensajes":
            return {
                ...state,
                mensajes: [
                    ...action.payload
                ]
            };
        default:
            return state;
    }
};

;// CONCATENATED MODULE: ./src/context/chat/ChatContext.tsx




const initialState = {
    uid: "",
    chatActivo: null,
    mensajes: []
};
const ChatContext = /*#__PURE__*/ (0,external_react_.createContext)({
});
const ChatProvider = ({ children  })=>{
    const { 0: chatState , 1: dispatch  } = (0,external_react_.useReducer)(chatReducer, initialState, undefined);
    const { 0: mensajePara , 1: setMensajePara  } = (0,external_react_.useState)("");
    const { 0: minimizarChat , 1: setMinimizarChat  } = (0,external_react_.useState)(true);
    const scrollToBotom = (0,external_react_.useRef)(null);
    const iniciarChat = async (data)=>{
        var ref;
        if (data.destinatario === data.remitente) return;
        await (0,fetch/* crearChat */.kP)("chats", data);
        dispatch({
            type: "ActivarChat",
            payload: data.destinatario
        });
        const resp = await (0,fetch/* obtenerMensajes */.Xo)(`mensajes/${data.destinatario}`);
        dispatch({
            type: "CargarMensajes",
            payload: resp.mensajes
        });
        (ref = scrollToBotom.current) === null || ref === void 0 ? void 0 : ref.scrollIntoView();
    };
    return(/*#__PURE__*/ jsx_runtime_.jsx(ChatContext.Provider, {
        value: {
            minimizarChat,
            setMinimizarChat,
            chatState,
            dispatch,
            mensajePara,
            setMensajePara,
            scrollToBotom,
            iniciarChat
        },
        children: children
    }));
};


/***/ })

};
;