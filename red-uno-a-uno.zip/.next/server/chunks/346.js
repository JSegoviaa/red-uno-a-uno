exports.id = 346;
exports.ids = [346];
exports.modules = {

/***/ 2564:
/***/ ((module) => {

// Exports
module.exports = {
	"loginTitle": "ModalTitle_loginTitle__yoRJH",
	"line": "ModalTitle_line__2J5OE"
};


/***/ }),

/***/ 4074:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _ModalTitle_module_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2564);
/* harmony import */ var _ModalTitle_module_css__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_ModalTitle_module_css__WEBPACK_IMPORTED_MODULE_1__);


const Modaltitle = ({ titulo  })=>{
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "text-center",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                className: (_ModalTitle_module_css__WEBPACK_IMPORTED_MODULE_1___default().loginTitle),
                children: titulo
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: (_ModalTitle_module_css__WEBPACK_IMPORTED_MODULE_1___default().line)
            })
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Modaltitle);


/***/ }),

/***/ 1267:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "c": () => (/* binding */ useForm)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

const useForm = (initialState)=>{
    const { 0: formulario , 1: setFormulario  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(initialState);
    const handleChange = ({ target  })=>{
        const { name , value  } = target;
        setFormulario({
            ...formulario,
            [name]: value
        });
    };
    return {
        formulario,
        handleChange,
        setFormulario
    };
};


/***/ })

};
;