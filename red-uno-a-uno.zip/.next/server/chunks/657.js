"use strict";
exports.id = 657;
exports.ids = [657];
exports.modules = {

/***/ 4657:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _react_google_maps_api__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2433);
/* harmony import */ var _react_google_maps_api__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_react_google_maps_api__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_bootstrap__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(358);
/* harmony import */ var react_bootstrap__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_bootstrap__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _context_auth_AuthContext__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1165);
/* harmony import */ var _ui_button_Button__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7924);
/* harmony import */ var _Inmueble_module_css__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(9344);
/* harmony import */ var _Inmueble_module_css__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_Inmueble_module_css__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _helpers_fetch__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(22);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1187);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_toastify__WEBPACK_IMPORTED_MODULE_6__);









const containerStyle = {
    width: "100%",
    height: "400px"
};
const Ubicacion = ({ inmuebles  })=>{
    const { auth  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_context_auth_AuthContext__WEBPACK_IMPORTED_MODULE_4__/* .AuthContext */ .V);
    const agregarFavorito = async (inmuebleId)=>{
        const favorito = {
            usuario: auth.uid,
            inmueble: inmuebleId,
            propietario: inmuebles.inmueble.usuario._id
        };
        const resp = await (0,_helpers_fetch__WEBPACK_IMPORTED_MODULE_7__/* .agregarFav */ .o4)("favoritos", favorito);
        if (resp.ok) {
            react_toastify__WEBPACK_IMPORTED_MODULE_6__.toast.success(resp.msg);
        }
        if (!resp.ok) {
            if (resp.errors) {
                resp.errors.map((error)=>{
                    react_toastify__WEBPACK_IMPORTED_MODULE_6__.toast.error(error.msg);
                });
            }
            if (!resp.ok) {
                react_toastify__WEBPACK_IMPORTED_MODULE_6__.toast.error(resp.msg);
            }
        }
    };
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
        className: "mt-5",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap__WEBPACK_IMPORTED_MODULE_3__.Container, {
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_bootstrap__WEBPACK_IMPORTED_MODULE_3__.Row, {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "col-sm-12 col-md-12 col-lg-6 col-xl-6",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_react_google_maps_api__WEBPACK_IMPORTED_MODULE_2__.GoogleMap, {
                            mapContainerStyle: containerStyle,
                            center: {
                                lat: inmuebles.inmueble.lat,
                                lng: inmuebles.inmueble.lng
                            },
                            zoom: 16,
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_react_google_maps_api__WEBPACK_IMPORTED_MODULE_2__.Marker, {
                                position: {
                                    lat: inmuebles.inmueble.lat,
                                    lng: inmuebles.inmueble.lng
                                },
                                icon: {
                                    url: "/images/icons/marcador.svg"
                                }
                            })
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "col-sm-12 col-md-12 col-lg-6 col-xl-6",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: `${(_Inmueble_module_css__WEBPACK_IMPORTED_MODULE_8___default().inmuebleTitleUbicacion)} mb-4`,
                                children: inmuebles.inmueble.titulo
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "mb-4",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "row",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "col-12 mb-4",
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                            className: `${(_Inmueble_module_css__WEBPACK_IMPORTED_MODULE_8___default().inmuebleTipo2)} me-4`,
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                    src: "/images/icons/deatails-icons/ubicacion.png",
                                                    alt: "...",
                                                    width: 25
                                                }),
                                                inmuebles.inmueble.direccion
                                            ]
                                        })
                                    })
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: (_Inmueble_module_css__WEBPACK_IMPORTED_MODULE_8___default().inmuebleContent),
                                children: inmuebles.inmueble.descripcion ? inmuebles.inmueble.descripcion : "A\xfan no hay descripci\xf3n para este inmueble"
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "col-12 text-center my-5",
                        children: auth.uid ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_button_Button__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                            titulo: "A\xf1adir a favoritos",
                            onClick: ()=>agregarFavorito(inmuebles.inmueble._id)
                        }) : null
                    })
                ]
            })
        })
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Ubicacion);


/***/ })

};
;