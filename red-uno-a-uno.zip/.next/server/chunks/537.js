exports.id = 537;
exports.ids = [537];
exports.modules = {

/***/ 2893:
/***/ ((module) => {

// Exports
module.exports = {
	"buscador": "Buscador_buscador__T0bve",
	"respuesta": "Buscador_respuesta__a37x9",
	"item": "Buscador_item__bLX3L",
	"buscador2": "Buscador_buscador2__yH_nM",
	"respuesta2": "Buscador_respuesta2__QI3Yv",
	"item2": "Buscador_item2__INoMs"
};


/***/ }),

/***/ 3537:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ propiedades_FormStepOne)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "react-bootstrap"
var external_react_bootstrap_ = __webpack_require__(358);
// EXTERNAL MODULE: ./src/components/ui/loading/Loading.tsx
var Loading = __webpack_require__(6220);
// EXTERNAL MODULE: ./src/components/paginas/perfil/propiedades/FormDesign.module.css
var FormDesign_module = __webpack_require__(3320);
var FormDesign_module_default = /*#__PURE__*/__webpack_require__.n(FormDesign_module);
;// CONCATENATED MODULE: ./src/hooks/useCategories.tsx

const devURL = "http://localhost:8080/api";
const baseURL = "https://prueba-red1a1.herokuapp.com/api";
const useCategories = ()=>{
    const { 0: cargando , 1: setCargando  } = (0,external_react_.useState)(true);
    const { 0: categorias , 1: setCategorias  } = (0,external_react_.useState)([]);
    const obtenerCategorias = async ()=>{
        const resp = await fetch(baseURL + "/categorias/");
        const data = await resp.json();
        setCategorias(data.categorias);
        setCargando(false);
    };
    (0,external_react_.useEffect)(()=>{
        obtenerCategorias();
    }, []);
    return {
        categorias,
        cargando
    };
};
const useTipoPropiedad = ()=>{
    const { 0: propertyTypes , 1: setPropertyTypes  } = (0,external_react_.useState)([]);
    const { 0: loading , 1: setLoading  } = (0,external_react_.useState)(true);
    const obtenerTipoPropiedad = async ()=>{
        const res = await fetch(`${baseURL}/tipo-de-propiedad`);
        const data = await res.json();
        setPropertyTypes(data.tipoPropiedad);
        setLoading(false);
    };
    (0,external_react_.useEffect)(()=>{
        obtenerTipoPropiedad();
    }, []);
    return {
        propertyTypes,
        loading
    };
};

// EXTERNAL MODULE: external "react-geosuggest"
var external_react_geosuggest_ = __webpack_require__(8580);
var external_react_geosuggest_default = /*#__PURE__*/__webpack_require__.n(external_react_geosuggest_);
// EXTERNAL MODULE: ./src/context/map/MapContext.tsx
var MapContext = __webpack_require__(1392);
// EXTERNAL MODULE: ./src/components/ui/buscador/Buscador.module.css
var Buscador_module = __webpack_require__(2893);
var Buscador_module_default = /*#__PURE__*/__webpack_require__.n(Buscador_module);
;// CONCATENATED MODULE: ./src/components/ui/buscador/SeleccionarLugar.tsx





const SeleccionarLugar = ()=>{
    const geosuggestEl = (0,external_react_.useRef)(null);
    const { setUbicacion , setDireccion  } = (0,external_react_.useContext)(MapContext/* MapContext */.X);
    const onSuggestSelect = (suggest)=>{
        if (!suggest) return;
        setDireccion(suggest.label);
        !suggest ? setUbicacion({
            lat: 19.4326077,
            lng: -99.133208
        }) : setUbicacion({
            lat: suggest.location.lat,
            lng: suggest.location.lng
        });
    };
    return(/*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ jsx_runtime_.jsx((external_react_geosuggest_default()), {
            ref: geosuggestEl,
            queryDelay: 530,
            country: "mx",
            placeholder: "Busca tu colonia aqu\xed...",
            onSuggestSelect: onSuggestSelect,
            autoComplete: "off",
            inputClassName: (Buscador_module_default()).buscador2,
            suggestsClassName: (Buscador_module_default()).respuesta2,
            suggestItemClassName: (Buscador_module_default()).item2
        })
    }));
};
/* harmony default export */ const buscador_SeleccionarLugar = (SeleccionarLugar);

// EXTERNAL MODULE: external "@react-google-maps/api"
var api_ = __webpack_require__(2433);
;// CONCATENATED MODULE: ./src/components/paginas/perfil/propiedades/MapaUbicacion.tsx




const containerStyle = {
    width: "100%",
    height: "500px"
};
const MapaUbicacion = ()=>{
    const { ubicacion , setUbicacion  } = (0,external_react_.useContext)(MapContext/* MapContext */.X);
    const onDragEnd = (e)=>{
        setUbicacion({
            lat: e.latLng.lat(),
            lng: e.latLng.lng()
        });
    };
    return(/*#__PURE__*/ jsx_runtime_.jsx(api_.GoogleMap, {
        mapContainerStyle: containerStyle,
        center: {
            lat: ubicacion.lat,
            lng: ubicacion.lng
        },
        zoom: 14,
        children: /*#__PURE__*/ jsx_runtime_.jsx(api_.Marker, {
            draggable: true,
            position: {
                lat: ubicacion.lat,
                lng: ubicacion.lng
            },
            onDragEnd: onDragEnd,
            icon: {
                url: "/images/icons/marcador.svg",
                scaledSize: new google.maps.Size(50, 50)
            }
        })
    }));
};
/* harmony default export */ const propiedades_MapaUbicacion = (MapaUbicacion);

// EXTERNAL MODULE: ./src/components/ui/button/Button.tsx
var Button = __webpack_require__(7924);
;// CONCATENATED MODULE: ./src/components/paginas/perfil/propiedades/FormStepOne.tsx










const FormStepOne = (props)=>{
    const { handleNextStep , handleChange , titulo , tipoPropiedad , setTipoPropiedad , precio , comisiones , categoria: categoria1 , setCategoria ,  } = props;
    const { direccion  } = (0,external_react_.useContext)(MapContext/* MapContext */.X);
    const { categorias , cargando  } = useCategories();
    const { loading , propertyTypes  } = useTipoPropiedad();
    const longitudTitulo = titulo.length;
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(external_react_bootstrap_.Form.Group, {
                className: "mb-3",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(external_react_bootstrap_.Form.Label, {
                        className: `${(FormDesign_module_default()).subTitulo}`,
                        children: "T\xedtulo del inmueble"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(external_react_bootstrap_.Form.Control, {
                        type: "text",
                        value: titulo,
                        name: "titulo",
                        onChange: handleChange
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(external_react_bootstrap_.Row, {
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(external_react_bootstrap_.Col, {
                                children: /*#__PURE__*/ jsx_runtime_.jsx(external_react_bootstrap_.Form.Text, {
                                    className: "text-muted",
                                    children: "Ej. Casa en venta en Palmaris, Canc\xfan"
                                })
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(external_react_bootstrap_.Col, {
                                className: "d-flex justify-content-end",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        style: {
                                            color: longitudTitulo > 75 ? "red" : "black"
                                        },
                                        children: longitudTitulo
                                    }),
                                    "/75"
                                ]
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(external_react_bootstrap_.Row, {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(external_react_bootstrap_.Col, {
                        md: 6,
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "row mb-3",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "col-sm-5 col-md-4 col-lg-6",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: (FormDesign_module_default()).content,
                                        children: "Tipo de inmueble"
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "col-sm-7 col-md-8 col-lg-6",
                                    children: loading ? /*#__PURE__*/ jsx_runtime_.jsx(Loading/* default */.Z, {
                                    }) : /*#__PURE__*/ jsx_runtime_.jsx(external_react_bootstrap_.Form.Select, {
                                        value: tipoPropiedad,
                                        onChange: (e)=>setTipoPropiedad(e.target.value)
                                        ,
                                        children: propertyTypes.map((propertyType)=>/*#__PURE__*/ jsx_runtime_.jsx("option", {
                                                value: propertyType._id,
                                                children: propertyType.nombre
                                            }, propertyType._id)
                                        )
                                    })
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(external_react_bootstrap_.Col, {
                        md: 6,
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "row mb-3",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "col-sm-5 col-md-4 col-lg-6",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: (FormDesign_module_default()).content,
                                        children: "Tipo de operaci\xf3n"
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "col-sm-7 col-md-8 col-lg-6",
                                    children: cargando ? /*#__PURE__*/ jsx_runtime_.jsx(Loading/* default */.Z, {
                                    }) : /*#__PURE__*/ jsx_runtime_.jsx(external_react_bootstrap_.Form.Select, {
                                        value: categoria1,
                                        onChange: (e)=>setCategoria(e.target.value)
                                        ,
                                        children: categorias.map((categoria)=>/*#__PURE__*/ jsx_runtime_.jsx("option", {
                                                value: categoria._id,
                                                children: categoria.nombre
                                            }, categoria._id)
                                        )
                                    })
                                })
                            ]
                        })
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (FormDesign_module_default()).MiniSub,
                children: "Ubicaci\xf3n"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (FormDesign_module_default()).line
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("br", {
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "row",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "col-12 mb-3",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(buscador_SeleccionarLugar, {
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "col-12 mb-5",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(propiedades_MapaUbicacion, {
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "col-sm-12 col-md-6 col-xxl-6",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "row d-flex justify-content-start",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "col-sm-12 col-xxl-3",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: (FormDesign_module_default()).labels2,
                                        children: "Valor"
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "col-sm-12 col-xxl-7",
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "input-group mb-3",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                className: "input-group-text",
                                                children: "$"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                                type: "number",
                                                className: "form-control",
                                                placeholder: "5,000.00",
                                                value: precio,
                                                name: "precio",
                                                onChange: handleChange,
                                                min: 0
                                            })
                                        ]
                                    })
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "col-sm-12 col-md-6 col-xxl-6",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "row d-flex justify-content-end",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "col-sm-12 col-xxl-5",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: (FormDesign_module_default()).labels2,
                                        children: "Comisiones"
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "col-sm-12 col-xxl-5",
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "input-group mb-3",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                className: "input-group-text",
                                                children: "%"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                                type: "number",
                                                className: "form-control",
                                                placeholder: "5",
                                                value: comisiones,
                                                name: "comisiones",
                                                onChange: handleChange,
                                                min: 0
                                            })
                                        ]
                                    })
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "col-12 my-4",
                        children: titulo.length === 0 || precio <= 0 || !direccion ? /*#__PURE__*/ jsx_runtime_.jsx(Button/* default */.Z, {
                            titulo: "Siguiente",
                            btn: "Disabled"
                        }) : /*#__PURE__*/ jsx_runtime_.jsx(Button/* default */.Z, {
                            titulo: "Siguiente",
                            onClick: handleNextStep
                        })
                    })
                ]
            })
        ]
    }));
};
/* harmony default export */ const propiedades_FormStepOne = (FormStepOne);


/***/ })

};
;