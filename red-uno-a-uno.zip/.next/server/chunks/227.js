"use strict";
exports.id = 227;
exports.ids = [227];
exports.modules = {

/***/ 4549:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "q": () => (/* binding */ InmuebleContext),
/* harmony export */   "K": () => (/* binding */ InmuebleProvider)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1187);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_toastify__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _helpers_fetch__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(22);




const InmuebleContext = /*#__PURE__*/ (0,react__WEBPACK_IMPORTED_MODULE_1__.createContext)({
});
const InmuebleProvider = ({ children  })=>{
    const { 0: orden , 1: setOrden  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("createdAt");
    const { 0: solicitud , 1: setSolicitud  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("Pendiente");
    const crearInmueble = async (data)=>{
        const resp = await (0,_helpers_fetch__WEBPACK_IMPORTED_MODULE_3__/* .fetchInmueble */ .oi)("inmuebles", data);
        if (resp.ok) {
            react_toastify__WEBPACK_IMPORTED_MODULE_2__.toast.success(resp.msg);
            react_toastify__WEBPACK_IMPORTED_MODULE_2__.toast.success("Ahora agrega las im\xe1genes de tu inmueble");
        }
        if (resp.errors) {
            resp.errors.map((e)=>{
                return react_toastify__WEBPACK_IMPORTED_MODULE_2__.toast.error(e.msg);
            });
        }
        return resp;
    };
    const subirImagenesInmueble = async (data, uid, pid)=>{
        const resp = await (0,_helpers_fetch__WEBPACK_IMPORTED_MODULE_3__/* .subirFotosInmueble */ .Fy)(`subidas/${uid}/${pid}`, data);
        if (resp.ok) {
            react_toastify__WEBPACK_IMPORTED_MODULE_2__.toast.success(resp.msg);
        }
        if (!resp.ok) {
            react_toastify__WEBPACK_IMPORTED_MODULE_2__.toast.error("Hubo un error al momento de subir las im\xe1genes. Int\xe9ntelo nuevamente");
        }
        return resp;
    };
    const eliminarInmueble = async (id)=>{
        const resp = await (0,_helpers_fetch__WEBPACK_IMPORTED_MODULE_3__/* .fetchBorrarInmueble */ .iE)(`inmuebles/${id}`);
        react_toastify__WEBPACK_IMPORTED_MODULE_2__.toast.success(resp.msg);
        return resp;
    };
    const actualizarInmueble = async (data, pid)=>{
        const resp = await (0,_helpers_fetch__WEBPACK_IMPORTED_MODULE_3__/* .fetchActualizarInmueble */ .dW)(`inmuebles/${pid}`, data);
        if (resp.ok) {
            react_toastify__WEBPACK_IMPORTED_MODULE_2__.toast.success(resp.msg);
        }
        if (!resp.ok) {
            react_toastify__WEBPACK_IMPORTED_MODULE_2__.toast.error(resp.msg);
        }
        return resp;
    };
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(InmuebleContext.Provider, {
        value: {
            crearInmueble,
            eliminarInmueble,
            subirImagenesInmueble,
            orden,
            setOrden,
            solicitud,
            setSolicitud,
            actualizarInmueble
        },
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_toastify__WEBPACK_IMPORTED_MODULE_2__.ToastContainer, {
            }),
            children
        ]
    }));
};


/***/ }),

/***/ 9227:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Pc": () => (/* binding */ useUserInfo),
/* harmony export */   "TL": () => (/* binding */ useUserInmuebles),
/* harmony export */   "s8": () => (/* binding */ useHistorial),
/* harmony export */   "eV": () => (/* binding */ useHistorialPagos),
/* harmony export */   "ah": () => (/* binding */ useMisUsuarios)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _context_inmuebles_InmuebleContext__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4549);
/* harmony import */ var _credentials_credentials__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6681);



const devURL = "http://localhost:8080/api";
const baseURL = "https://prueba-red1a1.herokuapp.com/api";
const useUserInfo = (uid)=>{
    const { 0: user , 1: setUser  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)();
    const { 0: loading , 1: setLoading  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(true);
    const getUserInfo = async ()=>{
        setLoading(true);
        const data = await fetch(baseURL + "/usuarios/" + uid);
        const resp = await data.json();
        setLoading(false);
        setUser(resp);
    };
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        getUserInfo();
    }, [
        uid
    ]);
    return {
        user,
        loading
    };
};
const useUserInmuebles = (uid, desde = 0)=>{
    const { 0: inmuebles , 1: setInmuebles  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)();
    const { 0: cargando , 1: setCargando  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(true);
    const { 0: total , 1: setTotal  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(0);
    const { orden  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useContext)(_context_inmuebles_InmuebleContext__WEBPACK_IMPORTED_MODULE_1__/* .InmuebleContext */ .q);
    const obtenerInmueblesDeUsuario = async ()=>{
        const data = await fetch(`${baseURL}/inmuebles/usuario/${uid}?orden=${orden}&limite=20&desde=${desde}`);
        const resp = await data.json();
        setInmuebles(resp.inmueblesUsuario);
        setCargando(false);
        setTotal(resp.total);
    };
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        obtenerInmueblesDeUsuario();
    }, [
        orden,
        desde,
        uid
    ]);
    return {
        inmuebles,
        cargando,
        total,
        setInmuebles
    };
};
const useHistorial = (uid, desde)=>{
    const { 0: historial , 1: setHistorial  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)();
    const { 0: isLoading , 1: setIsLoading  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(true);
    const { 0: total , 1: setTotal  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(0);
    const obtenerHistorial = async ()=>{
        const resp = await fetch(`${baseURL}/historial/usuario/${uid}?desde=${desde}&limite=15`);
        const data = await resp.json();
        setHistorial(data.historialUsuario);
        setTotal(data.total);
        setIsLoading(false);
    };
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        obtenerHistorial();
    }, [
        desde,
        uid
    ]);
    return {
        historial,
        isLoading,
        setHistorial,
        total
    };
};
const useHistorialPagos = (uid, desde)=>{
    const { 0: historialPago , 1: setHistorialPago  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]);
    const { 0: cargando , 1: setCargando  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(true);
    const { 0: total , 1: setTotal  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(0);
    const obtenerHistorialPagos = async ()=>{
        const resp = await fetch(`${_credentials_credentials__WEBPACK_IMPORTED_MODULE_2__/* .production */ .C}/pedidos/usuarios/${uid}?desde=${desde}&limite=15`);
        const data = await resp.json();
        setTotal(data.total);
        setHistorialPago(data.pedidosUsuario);
        setCargando(false);
    };
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        obtenerHistorialPagos();
    }, [
        desde,
        uid
    ]);
    return {
        historialPago,
        cargando,
        total
    };
};
const useMisUsuarios = (uid)=>{
    // const [misUsuarios, setMisUsuarios] = useState<UsuariosPagado[]>([]);
    const { 0: misUsuarios , 1: setMisUsuarios  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]);
    const { 0: cargando , 1: setCargando  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(true);
    const obtenerMisUsuarios = async ()=>{
        const res = await fetch(`${baseURL}/usuarios/propietario/${uid}`);
        const data = await res.json();
        setMisUsuarios(data.misUsuarios);
        setCargando(false);
    };
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        obtenerMisUsuarios();
    }, [
        uid
    ]);
    return {
        misUsuarios,
        cargando,
        setMisUsuarios
    };
};


/***/ })

};
;