exports.id = 884;
exports.ids = [884];
exports.modules = {

/***/ 2507:
/***/ ((module) => {

// Exports
module.exports = {
	"contenedorCard": "MapCards_contenedorCard__Fsb2U",
	"containerimg": "MapCards_containerimg__khGjT",
	"imgCard": "MapCards_imgCard__J8kCP",
	"title": "MapCards_title__Co0t5",
	"ciudad": "MapCards_ciudad__pXlFD",
	"operacion": "MapCards_operacion__l70Sg",
	"descripcion": "MapCards_descripcion__9IQVs",
	"precio": "MapCards_precio__9nnfP",
	"btnDetalle": "MapCards_btnDetalle__S_9aV"
};


/***/ }),

/***/ 3374:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _react_google_maps_api__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2433);
/* harmony import */ var _react_google_maps_api__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_react_google_maps_api__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var swiper__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3877);
/* harmony import */ var swiper_react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3015);
/* harmony import */ var _helpers_formatPrice__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(5762);
/* harmony import */ var _MapCards_module_css__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(2507);
/* harmony import */ var _MapCards_module_css__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_MapCards_module_css__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _context_auth_AuthContext__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1165);
/* harmony import */ var _helpers_fetch__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(22);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([swiper_react__WEBPACK_IMPORTED_MODULE_5__, swiper__WEBPACK_IMPORTED_MODULE_4__]);
([swiper_react__WEBPACK_IMPORTED_MODULE_5__, swiper__WEBPACK_IMPORTED_MODULE_4__] = __webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__);













swiper__WEBPACK_IMPORTED_MODULE_4__["default"].use([
    swiper__WEBPACK_IMPORTED_MODULE_4__.EffectCube,
    swiper__WEBPACK_IMPORTED_MODULE_4__.Pagination,
    swiper__WEBPACK_IMPORTED_MODULE_4__.Autoplay
]);
const InfoWindowMap = ({ inmueble  })=>{
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)();
    const { auth  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_context_auth_AuthContext__WEBPACK_IMPORTED_MODULE_6__/* .AuthContext */ .V);
    const handleProperty = async (id, slug)=>{
        const data = {
            usuario: auth.uid,
            inmueble: id
        };
        router.push(`/propiedades/${slug}`);
        await (0,_helpers_fetch__WEBPACK_IMPORTED_MODULE_7__/* .agregarHist */ .Fl)("historial", data);
    };
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_react_google_maps_api__WEBPACK_IMPORTED_MODULE_3__.InfoWindow, {
        position: {
            lat: inmueble.lat,
            lng: inmueble.lng
        },
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: (_MapCards_module_css__WEBPACK_IMPORTED_MODULE_8___default().contenedorCard),
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "row",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "col text-center",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: (_MapCards_module_css__WEBPACK_IMPORTED_MODULE_8___default().containerimg),
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(swiper_react__WEBPACK_IMPORTED_MODULE_5__.Swiper, {
                                effect: "cube",
                                grabCursor: true,
                                loop: true,
                                autoplay: {
                                    delay: 3200,
                                    disableOnInteraction: false,
                                    pauseOnMouseEnter: true
                                },
                                cubeEffect: {
                                    shadow: true,
                                    slideShadows: true,
                                    shadowOffset: 20,
                                    shadowScale: 0.94
                                },
                                className: "mySwiper",
                                children: inmueble.imgs.map((img)=>{
                                    const sepracion = img.split(".");
                                    const extension = sepracion[sepracion.length - 1];
                                    const extensionesValidas = [
                                        "mp4"
                                    ];
                                    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(swiper_react__WEBPACK_IMPORTED_MODULE_5__.SwiperSlide, {
                                        children: extensionesValidas.includes(extension) ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("video", {
                                            src: img,
                                            controls: true,
                                            controlsList: "nodownload",
                                            style: {
                                                height: 200,
                                                width: "100%",
                                                overflow: "hidden"
                                            }
                                        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                            className: (_MapCards_module_css__WEBPACK_IMPORTED_MODULE_8___default().imgCard),
                                            src: img
                                        })
                                    }, img));
                                })
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: `${(_MapCards_module_css__WEBPACK_IMPORTED_MODULE_8___default().title)} mb-2`,
                            children: inmueble.titulo
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "mb-2",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: `${(_MapCards_module_css__WEBPACK_IMPORTED_MODULE_8___default().operacion)}`,
                                children: inmueble.categoria.nombre
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: `${(_MapCards_module_css__WEBPACK_IMPORTED_MODULE_8___default().descripcion)} mb-2`,
                            children: inmueble.descripcion ? inmueble.descripcion : "Sin descripci\xf3n"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: `${(_MapCards_module_css__WEBPACK_IMPORTED_MODULE_8___default().precio)} mb-3`,
                            children: (0,_helpers_formatPrice__WEBPACK_IMPORTED_MODULE_9__/* .formatPrice */ .T)(inmueble.precio)
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "mb-2",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                className: (_MapCards_module_css__WEBPACK_IMPORTED_MODULE_8___default().btnDetalle),
                                onClick: ()=>handleProperty(inmueble._id, inmueble.slug)
                                ,
                                children: "Ver detalles"
                            })
                        })
                    ]
                })
            })
        })
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (InfoWindowMap);

});

/***/ }),

/***/ 8884:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _react_google_maps_api__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2433);
/* harmony import */ var _react_google_maps_api__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_react_google_maps_api__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _context_map_MapContext__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1392);
/* harmony import */ var _hooks_useInmuebles__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8605);
/* harmony import */ var _ui_loading_Loading__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6220);
/* harmony import */ var _InfoWindowMap__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(3374);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_InfoWindowMap__WEBPACK_IMPORTED_MODULE_6__]);
_InfoWindowMap__WEBPACK_IMPORTED_MODULE_6__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];







const containerStyle = {
    width: "100%",
    height: "87vh"
};
const options = {
    disableDefaultUI: true,
    streetViewControl: true,
    zoomControl: true,
    fullscreenControl: true
};
const MapaUbicacion = ()=>{
    const { coordenadas , zoom , setCoordenadas  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_context_map_MapContext__WEBPACK_IMPORTED_MODULE_3__/* .MapContext */ .X);
    const { inmuebles , cargando  } = (0,_hooks_useInmuebles__WEBPACK_IMPORTED_MODULE_4__/* .useInmuebles */ .q)();
    const { 0: seleccionado , 1: setSeleccionado  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const propiedadSeleccionada = (id, lat, lng)=>{
        setCoordenadas({
            lat,
            lng
        });
        setSeleccionado(id);
    };
    const closeInfoWindow = ()=>{
        setSeleccionado("");
    };
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_react_google_maps_api__WEBPACK_IMPORTED_MODULE_2__.GoogleMap, {
        mapContainerStyle: containerStyle,
        center: {
            lat: coordenadas.lat,
            lng: coordenadas.lng
        },
        onClick: closeInfoWindow,
        zoom: zoom,
        options: options,
        children: cargando ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_loading_Loading__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
            children: inmuebles === null || inmuebles === void 0 ? void 0 : inmuebles.filter((inmueble)=>{
                return inmueble.publicado === true;
            }).map((inmueble)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_react_google_maps_api__WEBPACK_IMPORTED_MODULE_2__.Marker, {
                    animation: 2,
                    position: {
                        lat: inmueble.lat,
                        lng: inmueble.lng
                    },
                    icon: {
                        url: "/images/icons/marcador.svg",
                        scaledSize: new google.maps.Size(50, 50)
                    },
                    onClick: ()=>propiedadSeleccionada(inmueble._id, inmueble.lat, inmueble.lng)
                    ,
                    children: seleccionado === inmueble._id ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_InfoWindowMap__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                        inmueble: inmueble
                    }) : null
                }, inmueble._id)
            )
        })
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (/*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_1__.memo)(MapaUbicacion));

});

/***/ })

};
;