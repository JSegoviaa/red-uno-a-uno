(() => {
var exports = {};
exports.id = 888;
exports.ids = [888];
exports.modules = {

/***/ 7415:
/***/ ((module) => {

// Exports
module.exports = {
	"VentanaChat": "Contenido_VentanaChat__LNywL",
	"header": "Contenido_header___HwuI",
	"perfilImg": "Contenido_perfilImg__RwB4Y",
	"nombre": "Contenido_nombre__ZvSQk",
	"conexion": "Contenido_conexion__nbZMV",
	"dashIcon": "Contenido_dashIcon__dpggg",
	"hora": "Contenido_hora__0uzaq",
	"chatBox": "Contenido_chatBox__wzlLF",
	"sendMensajeFooter": "Contenido_sendMensajeFooter__6TPfH",
	"btnEnviar": "Contenido_btnEnviar__BJV3T",
	"iconSend": "Contenido_iconSend__YG57X",
	"messageBox": "Contenido_messageBox__o7B1q",
	"mensaje1": "Contenido_mensaje1__npbQU",
	"mensaje2": "Contenido_mensaje2__ip34G"
};


/***/ }),

/***/ 8258:
/***/ ((module) => {

// Exports
module.exports = {
	"michat": "MisChats_michat__VuAIs",
	"ChatHover": "MisChats_ChatHover__U_YJo",
	"OFhead": "MisChats_OFhead__g45tf",
	"OFbody": "MisChats_OFbody__jLwff",
	"nombre": "MisChats_nombre__bKIGR",
	"mensaje": "MisChats_mensaje__FaQnJ",
	"backImg": "MisChats_backImg__rIRST"
};


/***/ }),

/***/ 4467:
/***/ ((module) => {

// Exports
module.exports = {
	"modalLabels": "AuthModal_modalLabels__T9Gnb",
	"modalInputs": "AuthModal_modalInputs__pKywC",
	"modalGoogleBtn": "AuthModal_modalGoogleBtn__5BN8B",
	"modalFbBtn": "AuthModal_modalFbBtn__jX4ZA",
	"modalContent": "AuthModal_modalContent__Bs1MU",
	"mostrarContraseña": "AuthModal_mostrarContrase_a__R5GLX"
};


/***/ }),

/***/ 2893:
/***/ ((module) => {

// Exports
module.exports = {
	"buscador": "Buscador_buscador__T0bve",
	"respuesta": "Buscador_respuesta__a37x9",
	"item": "Buscador_item__bLX3L",
	"buscador2": "Buscador_buscador2__yH_nM",
	"respuesta2": "Buscador_respuesta2__QI3Yv",
	"item2": "Buscador_item2__INoMs"
};


/***/ }),

/***/ 2566:
/***/ ((module) => {

// Exports
module.exports = {
	"footerContent": "Footer_footerContent__UgKm3",
	"footerStyle": "Footer_footerStyle__DQ7O6",
	"footerLink": "Footer_footerLink___LKy_",
	"footerPhone": "Footer_footerPhone__23_dN",
	"mbExtend": "Footer_mbExtend__Swhob"
};


/***/ }),

/***/ 8716:
/***/ ((module) => {

// Exports
module.exports = {
	"navStyle": "Header_navStyle__HBCv5",
	"navEnlace": "Header_navEnlace__TYTt8",
	"navPerfil": "Header_navPerfil__dF0Er",
	"sesionBtn": "Header_sesionBtn__pknjn",
	"menu": "Header_menu__Cd6rh",
	"menuItem": "Header_menuItem__Ca4o_",
	"menuCerrar": "Header_menuCerrar__tw89B"
};


/***/ }),

/***/ 7410:
/***/ ((module) => {

// Exports
module.exports = {
	"purple-nav": "PurpleHeader_purple-nav__g9zU8",
	"searchBtn": "PurpleHeader_searchBtn__XIuzm",
	"purpleNav2": "PurpleHeader_purpleNav2__PPyNA",
	"purpleLinks": "PurpleHeader_purpleLinks__iSDNA",
	"searchInput": "PurpleHeader_searchInput__Jib2q",
	"notificacion": "PurpleHeader_notificacion___ygw2"
};


/***/ }),

/***/ 6323:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _context_auth_AuthContext__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1165);
/* harmony import */ var _paginas_perfil_chats_VentanaChat__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3458);
/* harmony import */ var _ui_footer_Footer__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9348);
/* harmony import */ var _ui_header_Header__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8549);
/* harmony import */ var _ui_purpleheader_PurpleHeader__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6272);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_paginas_perfil_chats_VentanaChat__WEBPACK_IMPORTED_MODULE_3__]);
_paginas_perfil_chats_VentanaChat__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];







const Layout = ({ children  })=>{
    const { verificaToken  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_context_auth_AuthContext__WEBPACK_IMPORTED_MODULE_2__/* .AuthContext */ .V);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        verificaToken();
    }, [
        verificaToken
    ]);
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_header_Header__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_purpleheader_PurpleHeader__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
            }),
            children,
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_paginas_perfil_chats_VentanaChat__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ui_footer_Footer__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
            })
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Layout);

});

/***/ }),

/***/ 9756:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ chats_Mensaje)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
;// CONCATENATED MODULE: external "linkify-react"
const external_linkify_react_namespaceObject = require("linkify-react");
var external_linkify_react_default = /*#__PURE__*/__webpack_require__.n(external_linkify_react_namespaceObject);
// EXTERNAL MODULE: ./src/components/paginas/perfil/chats/Contenido.module.css
var Contenido_module = __webpack_require__(7415);
var Contenido_module_default = /*#__PURE__*/__webpack_require__.n(Contenido_module);
// EXTERNAL MODULE: ./src/helpers/horaMes.tsx
var horaMes = __webpack_require__(3289);
;// CONCATENATED MODULE: ./src/components/paginas/perfil/chats/Mensaje.tsx




const options = {
    defaultProtocol: "https",
    target: "_blank",
    rel: "noopener noreferrer"
};
const Mensaje = ({ mensaje , propio  })=>{
    return(/*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "col-11 mb-2",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: propio ? (Contenido_module_default()).mensaje2 : (Contenido_module_default()).mensaje1,
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx((external_linkify_react_default()), {
                    options: options,
                    children: mensaje.mensaje
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: `d-flex justify-content-end ${(Contenido_module_default()).hora}`,
                    children: (0,horaMes/* horaMes */._)(mensaje && mensaje.createdAt)
                })
            ]
        })
    }));
};
/* harmony default export */ const chats_Mensaje = (Mensaje);


/***/ }),

/***/ 3458:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_bootstrap__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(358);
/* harmony import */ var react_bootstrap__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_bootstrap__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _context_auth_AuthContext__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1165);
/* harmony import */ var _context_chat_ChatContext__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1458);
/* harmony import */ var _context_socket_SocketContext__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1810);
/* harmony import */ var _hooks_useForm__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1267);
/* harmony import */ var _hooks_useUserInfo__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(9227);
/* harmony import */ var _Contenido_module_css__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(7415);
/* harmony import */ var _Contenido_module_css__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_Contenido_module_css__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _Mensaje__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(9756);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_context_socket_SocketContext__WEBPACK_IMPORTED_MODULE_5__]);
_context_socket_SocketContext__WEBPACK_IMPORTED_MODULE_5__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];










const VentanaChat = ()=>{
    const { auth  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_context_auth_AuthContext__WEBPACK_IMPORTED_MODULE_3__/* .AuthContext */ .V);
    const { socket  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_context_socket_SocketContext__WEBPACK_IMPORTED_MODULE_5__/* .SocketContext */ .J);
    const { setMinimizarChat , minimizarChat , chatState , dispatch , mensajePara , scrollToBotom ,  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_context_chat_ChatContext__WEBPACK_IMPORTED_MODULE_4__/* .ChatContext */ .p5);
    const { user  } = (0,_hooks_useUserInfo__WEBPACK_IMPORTED_MODULE_7__/* .useUserInfo */ .Pc)(chatState.chatActivo || mensajePara);
    const scrollTo = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(null);
    const { 0: limite , 1: setLimite  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(0);
    const { formulario , handleChange , setFormulario  } = (0,_hooks_useForm__WEBPACK_IMPORTED_MODULE_6__/* .useForm */ .c)({
        mensaje: ""
    });
    const { mensaje: mensaje1  } = formulario;
    const ocultarVentana = ()=>dispatch({
            type: "DesactivarChat",
            payload: null
        })
    ;
    const minimizarVentana = ()=>setMinimizarChat(!minimizarChat)
    ;
    const handleSubmit = async (e)=>{
        e.preventDefault();
        if (mensaje1.length === 0) return;
        const nuevoMensaje = {
            remitente: auth.uid,
            mensaje: mensaje1,
            para: chatState.chatActivo,
            conversacion: chatState.chatActivo
        };
        socket === null || socket === void 0 ? void 0 : socket.emit("mensaje-personal", nuevoMensaje);
        setFormulario({
            mensaje: ""
        });
    };
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        var ref;
        (ref = scrollTo.current) === null || ref === void 0 ? void 0 : ref.scrollIntoView({
            behavior: "smooth"
        });
    }, [
        chatState.mensajes
    ]);
    const cargarMasMensajes = ()=>{
        console.log("cargar m\xe1s mensajes");
    };
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
        children: chatState.chatActivo ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: (_Contenido_module_css__WEBPACK_IMPORTED_MODULE_9___default().VentanaChat),
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "row",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "col-12",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: (_Contenido_module_css__WEBPACK_IMPORTED_MODULE_9___default().header),
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "row",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "col-2 text-end",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                            className: (_Contenido_module_css__WEBPACK_IMPORTED_MODULE_9___default().perfilImg),
                                            src: user === null || user === void 0 ? void 0 : user.img,
                                            alt: user === null || user === void 0 ? void 0 : user.nombre
                                        })
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "col-7",
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: `${(_Contenido_module_css__WEBPACK_IMPORTED_MODULE_9___default().nombre)}`,
                                                children: [
                                                    user === null || user === void 0 ? void 0 : user.nombre,
                                                    " ",
                                                    user === null || user === void 0 ? void 0 : user.apellido
                                                ]
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: (_Contenido_module_css__WEBPACK_IMPORTED_MODULE_9___default().conexion),
                                                children: (user === null || user === void 0 ? void 0 : user.online) ? "En l\xednea" : "Desconectado"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "col-3 text-end p-0",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                                onClick: minimizarVentana,
                                                className: `${(_Contenido_module_css__WEBPACK_IMPORTED_MODULE_9___default().dashIcon)} ${minimizarChat ? "bi bi-dash-lg" : "bi bi-app"}  me-2 pointer`
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                onClick: ocultarVentana,
                                                type: "button",
                                                className: "btn-close btn-close-white mt-3 me-3",
                                                "aria-label": "Close"
                                            })
                                        ]
                                    })
                                ]
                            })
                        })
                    }),
                    minimizarChat ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "col-12",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: (_Contenido_module_css__WEBPACK_IMPORTED_MODULE_9___default().chatBox),
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "row d-flex justify-content-center",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: "text-center",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                                    onClick: cargarMasMensajes,
                                                    className: "bi bi-arrow-bar-up pointer",
                                                    style: {
                                                        fontSize: 25
                                                    }
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                children: chatState.mensajes.map((mensaje)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        ref: scrollToBotom,
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                            ref: scrollTo,
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Mensaje__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                                                                mensaje: mensaje,
                                                                propio: mensaje.remitente === auth.uid
                                                            })
                                                        })
                                                    }, mensaje._id)
                                                )
                                            })
                                        ]
                                    })
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "col-12",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: (_Contenido_module_css__WEBPACK_IMPORTED_MODULE_9___default().sendMensajeFooter),
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "row d-flex justify-content-center",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "col-12",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap__WEBPACK_IMPORTED_MODULE_2__.Form, {
                                                onSubmit: handleSubmit,
                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                    className: "input-group",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                            type: "text",
                                                            className: `${(_Contenido_module_css__WEBPACK_IMPORTED_MODULE_9___default().messageBox)} form-control`,
                                                            placeholder: "Mensaje...",
                                                            value: mensaje1,
                                                            onChange: handleChange,
                                                            name: "mensaje",
                                                            autoComplete: "off"
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                            className: `${(_Contenido_module_css__WEBPACK_IMPORTED_MODULE_9___default().btnEnviar)} input-group-text`,
                                                            id: "basic-addon2",
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                                className: (_Contenido_module_css__WEBPACK_IMPORTED_MODULE_9___default().iconSend),
                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                                                    className: "bi bi-send text-white"
                                                                })
                                                            })
                                                        })
                                                    ]
                                                })
                                            })
                                        })
                                    })
                                })
                            })
                        ]
                    }) : null
                ]
            })
        }) : null
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (VentanaChat);

});

/***/ }),

/***/ 4078:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_bootstrap__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(358);
/* harmony import */ var react_bootstrap__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_bootstrap__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1187);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_toastify__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _hooks_useForm__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1267);
/* harmony import */ var _button_Button__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7924);
/* harmony import */ var _modaltitle_Modaltitle__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(4074);
/* harmony import */ var _AuthModal_module_css__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(4467);
/* harmony import */ var _AuthModal_module_css__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(_AuthModal_module_css__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(8819);
/* harmony import */ var react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _context_auth_AuthContext__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(1165);
/* harmony import */ var react_google_login__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(67);
/* harmony import */ var react_google_login__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(react_google_login__WEBPACK_IMPORTED_MODULE_10__);












const RegisterModal = ()=>{
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)();
    const { 0: showPassword , 1: setShowPassword  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const { 0: showPassword2 , 1: setShowPassword2  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const { register , mostrarRegistro , cerrarRegistro , abrirLogin , signInWithGoogle ,  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_context_auth_AuthContext__WEBPACK_IMPORTED_MODULE_9__/* .AuthContext */ .V);
    const { formulario , handleChange  } = (0,_hooks_useForm__WEBPACK_IMPORTED_MODULE_5__/* .useForm */ .c)({
        nombre: "",
        apellido: "",
        correo: "",
        password: "",
        password2: "",
        role: "Usuario"
    });
    const { nombre , apellido , correo , password , password2 , role  } = formulario;
    const onSubmit = async (e1)=>{
        e1.preventDefault();
        if (password !== password2) react_toastify__WEBPACK_IMPORTED_MODULE_4__.toast.error("Las contrase\xf1as no coinciden");
        if (password.length < 6) {
            react_toastify__WEBPACK_IMPORTED_MODULE_4__.toast.error("La contrase\xf1a tiene que ser de al menos 6 caracteres");
        }
        if (password === password2) {
            const resp = await register(nombre, apellido, correo, password, role);
            if (resp.errors) {
                resp.errors.map((e)=>{
                    return react_toastify__WEBPACK_IMPORTED_MODULE_4__.toast.error(e.msg);
                });
            }
            if (resp.ok) {
                router.push("/perfil");
                cerrarRegistro();
            }
        }
    };
    const handleModals = ()=>{
        cerrarRegistro();
        abrirLogin();
    };
    const mostrarContraseña = ()=>setShowPassword(!showPassword)
    ;
    const mostrarContraseña2 = ()=>setShowPassword2(!showPassword2)
    ;
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_bootstrap__WEBPACK_IMPORTED_MODULE_3__.Modal, {
            show: mostrarRegistro,
            onHide: cerrarRegistro,
            contentClassName: (_AuthModal_module_css__WEBPACK_IMPORTED_MODULE_11___default().modalContent),
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap__WEBPACK_IMPORTED_MODULE_3__.Modal.Header, {
                    closeButton: true,
                    style: {
                        border: "none"
                    }
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_toastify__WEBPACK_IMPORTED_MODULE_4__.ToastContainer, {
                    autoClose: 10000
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap__WEBPACK_IMPORTED_MODULE_3__.Modal.Body, {
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_bootstrap__WEBPACK_IMPORTED_MODULE_3__.Form, {
                        onSubmit: onSubmit,
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "row d-flex justify-content-center",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_modaltitle_Modaltitle__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                    titulo: "Registrarse"
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "col-10",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                            className: (_AuthModal_module_css__WEBPACK_IMPORTED_MODULE_11___default().modalLabels),
                                            children: "Nombre"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                            className: `${(_AuthModal_module_css__WEBPACK_IMPORTED_MODULE_11___default().modalInputs)} mb-4`,
                                            type: "mail",
                                            name: "nombre",
                                            value: nombre,
                                            onChange: handleChange,
                                            required: true
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "col-10",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                            className: (_AuthModal_module_css__WEBPACK_IMPORTED_MODULE_11___default().modalLabels),
                                            children: "Apellidos"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                            className: `${(_AuthModal_module_css__WEBPACK_IMPORTED_MODULE_11___default().modalInputs)} mb-4`,
                                            type: "mail",
                                            name: "apellido",
                                            value: apellido,
                                            onChange: handleChange,
                                            required: true
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "col-10",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                            className: (_AuthModal_module_css__WEBPACK_IMPORTED_MODULE_11___default().modalLabels),
                                            children: "Correo electr\xf3nico"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                            className: `${(_AuthModal_module_css__WEBPACK_IMPORTED_MODULE_11___default().modalInputs)} mb-4`,
                                            type: "mail",
                                            name: "correo",
                                            value: correo,
                                            onChange: handleChange,
                                            required: true
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "col-10",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                            className: (_AuthModal_module_css__WEBPACK_IMPORTED_MODULE_11___default().modalLabels),
                                            children: "Contrase\xf1a"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                    className: `${(_AuthModal_module_css__WEBPACK_IMPORTED_MODULE_11___default().modalInputs)} mb-4`,
                                                    type: showPassword ? "text" : "password",
                                                    name: "password",
                                                    value: password,
                                                    onChange: handleChange,
                                                    required: true
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                                    onClick: mostrarContraseña,
                                                    className: `${showPassword ? "bi bi-eye-slash" : "bi bi-eye"} ${(_AuthModal_module_css__WEBPACK_IMPORTED_MODULE_11___default()["mostrarContraseña"])}`
                                                })
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "col-10",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                            className: (_AuthModal_module_css__WEBPACK_IMPORTED_MODULE_11___default().modalLabels),
                                            children: "Confirme su contrase\xf1a"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                    className: `${(_AuthModal_module_css__WEBPACK_IMPORTED_MODULE_11___default().modalInputs)} mb-4`,
                                                    type: showPassword2 ? "text" : "password",
                                                    name: "password2",
                                                    value: password2,
                                                    onChange: handleChange,
                                                    required: true
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                                    onClick: mostrarContraseña2,
                                                    className: `${showPassword2 ? "bi bi-eye-slash" : "bi bi-eye"} ${(_AuthModal_module_css__WEBPACK_IMPORTED_MODULE_11___default()["mostrarContraseña"])}`
                                                })
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "col-10 mb-3 text-center",
                                    children: nombre.length > 0 && apellido.length > 0 && correo.length > 0 && password.length > 0 && password2.length > 0 ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_button_Button__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                                        titulo: "Registrarse"
                                    }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_button_Button__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                                        titulo: "Registrarse",
                                        btn: "Disabled"
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "col-4 my-4",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("hr", {
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "col-2 text-center my-4 modal-labels",
                                    children: "O"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "col-4 my-4",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("hr", {
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_google_login__WEBPACK_IMPORTED_MODULE_10___default()), {
                                    clientId: "89650619107-jecf46e28s507h50vrtpfadtf44u2hmc.apps.googleusercontent.com",
                                    buttonText: "Inicia sesi\xf3n con google",
                                    onSuccess: signInWithGoogle,
                                    onFailure: signInWithGoogle,
                                    cookiePolicy: "single_host_origin",
                                    render: (renderProps)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            onClick: renderProps.onClick,
                                            className: "col-10 mb-3 text-center pointer",
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: (_AuthModal_module_css__WEBPACK_IMPORTED_MODULE_11___default().modalGoogleBtn),
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                                        className: "me-3",
                                                        src: "/images/icons/google-icon.png",
                                                        alt: "Inicia sesi\xf3n con google"
                                                    }),
                                                    "Reg\xedstrate con Google"
                                                ]
                                            })
                                        })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "text-center",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        onClick: handleModals,
                                        className: "pointer",
                                        style: {
                                            color: "#3D87F6"
                                        },
                                        children: "\xbfYa tienes cuenta? \xa1Inicia sesi\xf3n!"
                                    })
                                })
                            ]
                        })
                    })
                })
            ]
        })
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (RegisterModal);


/***/ }),

/***/ 9348:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1664);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _Footer_module_css__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(2566);
/* harmony import */ var _Footer_module_css__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_Footer_module_css__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _authmodal_AuthModal__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4078);
/* harmony import */ var _context_auth_AuthContext__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1165);







const Footer = ()=>{
    const { auth , abrirRegistro , cerrarRegistro , mostrarRegistro , setMostrarRegistro ,  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_context_auth_AuthContext__WEBPACK_IMPORTED_MODULE_5__/* .AuthContext */ .V);
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_3__.useRouter)();
    const goToHome = ()=>router.push("/")
    ;
    return(/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("footer", {
        className: `text-center text-lg-start text-muted ${(_Footer_module_css__WEBPACK_IMPORTED_MODULE_6___default().footerStyle)}`,
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
                className: "d-flex justify-content-center justify-content-lg-between p-4",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "me-5 d-none d-lg-block"
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
                className: (_Footer_module_css__WEBPACK_IMPORTED_MODULE_6___default().mbExtend),
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "container text-center text-md-start mt-5",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "row mt-3",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "col-sm-12 col-md-6 p-4 col-xl-5",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h6", {
                                        className: "text-uppercase mb-4",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                            onClick: goToHome,
                                            className: "pointer",
                                            src: "/images/logos/red1a1-blanco.png"
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                        className: (_Footer_module_css__WEBPACK_IMPORTED_MODULE_6___default().footerContent),
                                        children: "Red 1a1 es la soluci\xf3n para asesores independientes e inmobiliarias que permite la comunicaci\xf3n y el intercambio de carteras de clientes y propiedades. A trav\xe9s de esta herramienta vers\xe1til podr\xe1s agregar, buscar y compartir propiedades."
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "col-sm-12 col-md-6 p-4 col-xl-2",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                                        className: "fw-bold text-white mb-4",
                                        children: "Secciones"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_link__WEBPACK_IMPORTED_MODULE_2__["default"], {
                                        href: "/nosotros",
                                        scroll: true,
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                            className: `${(_Footer_module_css__WEBPACK_IMPORTED_MODULE_6___default().footerLink)} pointer`,
                                            children: "Nosotros"
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_link__WEBPACK_IMPORTED_MODULE_2__["default"], {
                                        href: "/paquetes",
                                        scroll: true,
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                            className: `${(_Footer_module_css__WEBPACK_IMPORTED_MODULE_6___default().footerLink)} pointer`,
                                            children: "Paquetes"
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_link__WEBPACK_IMPORTED_MODULE_2__["default"], {
                                        href: "/contacto",
                                        scroll: true,
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                            className: `${(_Footer_module_css__WEBPACK_IMPORTED_MODULE_6___default().footerLink)} pointer`,
                                            children: "Cont\xe1ctanos"
                                        })
                                    }),
                                    !auth.logged ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                        onClick: abrirRegistro,
                                        className: `${(_Footer_module_css__WEBPACK_IMPORTED_MODULE_6___default().footerLink)} pointer`,
                                        children: "Registro"
                                    }) : null
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "col-sm-12 col-md-6 p-4 col-xl-2",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                                        className: "fw-bold text-white mb-4",
                                        children: "Nuestras Oficinas"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                        className: (_Footer_module_css__WEBPACK_IMPORTED_MODULE_6___default().footerContent),
                                        children: "Quer\xe9taro, M\xe9xico. C.P. 76230"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "col-sm-12 col-md-6 p-4 col-xl-3",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                                        className: "fw-bold text-white mb-4",
                                        children: "Tel\xe9fono"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: (_Footer_module_css__WEBPACK_IMPORTED_MODULE_6___default().footerContent),
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                            className: (_Footer_module_css__WEBPACK_IMPORTED_MODULE_6___default().footerPhone),
                                            children: "442 543 9190"
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                        className: "me-2",
                                        href: "https://www.facebook.com",
                                        target: "_blank",
                                        rel: "noopener noreferrer",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                            src: "/images/icons/facebook.png",
                                            alt: "S\xedguenos en facebook"
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                        href: "https://wa.link/8udscw",
                                        target: "_blank",
                                        rel: "noopener noreferrer",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                            src: "/images/icons/whatsapp.png",
                                            alt: "Comun\xedcate por whatsapp"
                                        })
                                    })
                                ]
                            })
                        ]
                    })
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "text-center p-4",
                style: {
                    backgroundColor: "rgba(0, 0, 0, 0.05)"
                },
                children: [
                    "Copyright \xa9 ",
                    new Date().getFullYear(),
                    ":",
                    " ",
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_link__WEBPACK_IMPORTED_MODULE_2__["default"], {
                        href: "/",
                        scroll: true,
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            className: "text-reset fw-bold pointer",
                            style: {
                                textDecoration: "none"
                            },
                            children: "Red 1 a 1"
                        })
                    }),
                    ". Todos los derechos reservados."
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_authmodal_AuthModal__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                show: mostrarRegistro,
                handleClose: cerrarRegistro
            })
        ]
    }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Footer);


/***/ }),

/***/ 8549:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ header_Header)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
// EXTERNAL MODULE: external "react-bootstrap"
var external_react_bootstrap_ = __webpack_require__(358);
// EXTERNAL MODULE: ./src/components/ui/button/Button.tsx
var Button = __webpack_require__(7924);
// EXTERNAL MODULE: ./src/components/ui/header/Header.module.css
var Header_module = __webpack_require__(8716);
var Header_module_default = /*#__PURE__*/__webpack_require__.n(Header_module);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
// EXTERNAL MODULE: external "react-toastify"
var external_react_toastify_ = __webpack_require__(1187);
// EXTERNAL MODULE: external "react-google-login"
var external_react_google_login_ = __webpack_require__(67);
// EXTERNAL MODULE: ./src/context/auth/AuthContext.tsx
var AuthContext = __webpack_require__(1165);
// EXTERNAL MODULE: ./src/hooks/useForm.tsx
var useForm = __webpack_require__(1267);
// EXTERNAL MODULE: ./src/components/ui/modaltitle/Modaltitle.tsx
var Modaltitle = __webpack_require__(4074);
// EXTERNAL MODULE: ./src/components/ui/authmodal/AuthModal.module.css
var AuthModal_module = __webpack_require__(4467);
var AuthModal_module_default = /*#__PURE__*/__webpack_require__.n(AuthModal_module);
// EXTERNAL MODULE: ./node_modules/react-toastify/dist/ReactToastify.css
var ReactToastify = __webpack_require__(8819);
;// CONCATENATED MODULE: ./src/components/ui/authmodal/LoginModal.tsx












const LoginModal = ()=>{
    const router = (0,router_.useRouter)();
    const { 0: showPassword , 1: setShowPassword  } = (0,external_react_.useState)(false);
    const { login , mostrarLogin , cerrarLogin , abrirRegistro , signInWithGoogle  } = (0,external_react_.useContext)(AuthContext/* AuthContext */.V);
    const { formulario , handleChange , setFormulario  } = (0,useForm/* useForm */.c)({
        correo: "",
        password: "",
        rememberme: false
    });
    (0,external_react_.useEffect)(()=>{
        const correo = localStorage.getItem("correo");
        if (correo) {
            setFormulario({
                ...formulario,
                correo,
                rememberme: true
            });
        }
    }, []);
    const { correo: correo1 , password , rememberme  } = formulario;
    const toggleCheck = ()=>{
        setFormulario({
            ...formulario,
            rememberme: !rememberme
        });
    };
    const onSubmit = async (e)=>{
        e.preventDefault();
        rememberme ? localStorage.setItem("correo", correo1) : localStorage.removeItem("correo");
        const resp = await login(correo1, password);
        if (!resp.ok) {
            external_react_toastify_.toast.error(resp.msg);
        }
        if (resp.ok) {
            router.push("/perfil");
            cerrarLogin();
        }
    };
    const mostrarContraseña = ()=>setShowPassword(!showPassword)
    ;
    const handleModals = ()=>{
        cerrarLogin();
        abrirRegistro();
    };
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)(external_react_bootstrap_.Modal, {
        show: mostrarLogin,
        onHide: cerrarLogin,
        contentClassName: (AuthModal_module_default()).modalContent,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(external_react_bootstrap_.Modal.Header, {
                closeButton: true,
                style: {
                    border: "none"
                }
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(external_react_toastify_.ToastContainer, {
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(external_react_bootstrap_.Modal.Body, {
                children: /*#__PURE__*/ jsx_runtime_.jsx(external_react_bootstrap_.Form, {
                    onSubmit: onSubmit,
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "row d-flex justify-content-center",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(Modaltitle/* default */.Z, {
                                titulo: "Inicia sesi\xf3n"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "col-10",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                        className: (AuthModal_module_default()).modalLabels,
                                        children: "Correo electr\xf3nico"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("br", {
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                        className: `${(AuthModal_module_default()).modalInputs} mb-4`,
                                        type: "mail",
                                        name: "correo",
                                        value: correo1,
                                        onChange: handleChange,
                                        required: true
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "col-10",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                        className: (AuthModal_module_default()).modalLabels,
                                        children: "Contrase\xf1a"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("br", {
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                                className: `${(AuthModal_module_default()).modalInputs} mb-4`,
                                                type: showPassword ? "text" : "password",
                                                name: "password",
                                                value: password,
                                                onChange: handleChange,
                                                required: true
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                onClick: mostrarContraseña,
                                                className: `${showPassword ? "bi bi-eye-slash" : "bi bi-eye"} ${(AuthModal_module_default())["mostrarContraseña"]}`
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "col-4 my-4",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("hr", {
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "col-2 text-center my-4 modal-labels",
                                children: "O"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "col-4 my-4",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("hr", {
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(external_react_google_login_.GoogleLogin, {
                                clientId: "89650619107-jecf46e28s507h50vrtpfadtf44u2hmc.apps.googleusercontent.com",
                                buttonText: "Inicia sesi\xf3n con google",
                                onSuccess: signInWithGoogle,
                                onFailure: signInWithGoogle,
                                cookiePolicy: "single_host_origin",
                                render: (renderProps)=>/*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        onClick: renderProps.onClick,
                                        className: "col-10 mb-3 text-center pointer",
                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: (AuthModal_module_default()).modalGoogleBtn,
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                                    className: "me-3",
                                                    src: "/images/icons/google-icon.png",
                                                    alt: "Inicia sesi\xf3n con google"
                                                }),
                                                "Inicia sesi\xf3n con Google"
                                            ]
                                        })
                                    })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "col-10 mb-3",
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "form-check",
                                    onClick: ()=>toggleCheck()
                                    ,
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                            className: "form-check-input",
                                            type: "checkbox",
                                            name: "rememberme",
                                            checked: rememberme,
                                            readOnly: true
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                            className: "modal-labels",
                                            children: "Recordarme"
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "col-10 mb-3 text-center",
                                children: correo1.length > 0 && password.length > 0 ? /*#__PURE__*/ jsx_runtime_.jsx(Button/* default */.Z, {
                                    titulo: "Iniciar sesi\xf3n"
                                }) : /*#__PURE__*/ jsx_runtime_.jsx(Button/* default */.Z, {
                                    titulo: "Iniciar sesi\xf3n",
                                    btn: "Disabled"
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "text-center",
                                style: {
                                    color: "#3D87F6"
                                },
                                children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    onClick: handleModals,
                                    className: "pointer",
                                    children: "\xbfA\xfan no tienes cuenta? \xa1Reg\xedstrate!"
                                })
                            })
                        ]
                    })
                })
            })
        ]
    }));
};
/* harmony default export */ const authmodal_LoginModal = (LoginModal);

// EXTERNAL MODULE: ./src/components/ui/authmodal/AuthModal.tsx
var AuthModal = __webpack_require__(4078);
// EXTERNAL MODULE: ./src/credentials/credentials.tsx
var credentials = __webpack_require__(6681);
;// CONCATENATED MODULE: ./src/hooks/useConversaciones.tsx


const useConversaciones = (uid)=>{
    const { 0: conversaciones , 1: setConversaciones  } = (0,external_react_.useState)([]);
    const { 0: cargando , 1: setCargando  } = (0,external_react_.useState)(false);
    const obtenerConversaciones = async ()=>{
        setCargando(true);
        const resp = await fetch(`${credentials/* production */.C}/chats/${uid}`);
        const data = await resp.json();
        setConversaciones(data);
        setCargando(false);
    };
    (0,external_react_.useEffect)(()=>{
        obtenerConversaciones();
    }, [
        uid
    ]);
    return {
        conversaciones,
        cargando
    };
};

// EXTERNAL MODULE: ./src/components/ui/loading/Loading.tsx
var Loading = __webpack_require__(6220);
// EXTERNAL MODULE: ./src/context/chat/ChatContext.tsx + 1 modules
var ChatContext = __webpack_require__(1458);
// EXTERNAL MODULE: ./src/helpers/fetch.tsx
var helpers_fetch = __webpack_require__(22);
// EXTERNAL MODULE: ./src/components/paginas/perfil/chats/MisChats.module.css
var MisChats_module = __webpack_require__(8258);
var MisChats_module_default = /*#__PURE__*/__webpack_require__.n(MisChats_module);
;// CONCATENATED MODULE: ./src/components/paginas/perfil/chats/Chat.tsx







const Chat = ({ handleCloseCanvas , conversacion  })=>{
    const { dispatch , scrollToBotom  } = (0,external_react_.useContext)(ChatContext/* ChatContext */.p5);
    const { auth  } = (0,external_react_.useContext)(AuthContext/* AuthContext */.V);
    const { 0: contacto1 , 1: setContacto  } = (0,external_react_.useState)();
    (0,external_react_.useEffect)(()=>{
        const contacto = conversacion.miembros.find((miembro)=>miembro !== auth.uid
        );
        const traerContacto = async ()=>{
            const resp = await fetch(`${credentials/* production */.C}/usuarios/${contacto}`);
            const data = await resp.json();
            setContacto(data);
        };
        traerContacto();
    }, [
        conversacion,
        auth
    ]);
    const activarChat = async ()=>{
        var ref;
        dispatch({
            type: "ActivarChat",
            payload: contacto1 === null || contacto1 === void 0 ? void 0 : contacto1.uid
        });
        const resp = await (0,helpers_fetch/* obtenerMensajes */.Xo)(`mensajes/${contacto1 === null || contacto1 === void 0 ? void 0 : contacto1.uid}`);
        dispatch({
            type: "CargarMensajes",
            payload: resp.mensajes
        });
        (ref = scrollToBotom.current) === null || ref === void 0 ? void 0 : ref.scrollIntoView();
    };
    return(/*#__PURE__*/ jsx_runtime_.jsx("div", {
        onClick: handleCloseCanvas,
        className: `${(MisChats_module_default()).ChatHover} pointer mb-2`,
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: (MisChats_module_default()).michat,
            onClick: activarChat,
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "row",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "col-2 text-center",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: (MisChats_module_default()).backImg,
                            children: contacto1 ? /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                src: contacto1.img,
                                alt: contacto1.nombre,
                                style: {
                                    borderRadius: "50%",
                                    width: 55,
                                    height: 55
                                }
                            }) : null
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "col-10",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: (MisChats_module_default()).nombre,
                                children: contacto1 ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                                    children: [
                                        contacto1.nombre,
                                        " ",
                                        contacto1.apellido
                                    ]
                                }) : null
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: (MisChats_module_default()).mensaje,
                                children: "Mensaje est\xe1tico"
                            })
                        ]
                    })
                ]
            })
        })
    }));
};
/* harmony default export */ const chats_Chat = (Chat);

;// CONCATENATED MODULE: ./src/components/paginas/perfil/chats/MisChats.tsx








const MisChats = ({ showCanvas , handleCloseCanvas  })=>{
    const { auth  } = (0,external_react_.useContext)(AuthContext/* AuthContext */.V);
    const { conversaciones , cargando  } = useConversaciones(auth.uid);
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)(external_react_bootstrap_.Offcanvas, {
        show: showCanvas,
        onHide: handleCloseCanvas,
        placement: "end",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(external_react_bootstrap_.Offcanvas.Header, {
                closeButton: true,
                className: (MisChats_module_default()).OFhead,
                children: /*#__PURE__*/ jsx_runtime_.jsx(external_react_bootstrap_.Offcanvas.Title, {
                    children: "Mis chats"
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(external_react_bootstrap_.Offcanvas.Body, {
                className: (MisChats_module_default()).OFbody,
                children: conversaciones.map((conversacion)=>/*#__PURE__*/ jsx_runtime_.jsx(external_react_.Fragment, {
                        children: cargando ? /*#__PURE__*/ jsx_runtime_.jsx(Loading/* default */.Z, {
                        }) : /*#__PURE__*/ jsx_runtime_.jsx(chats_Chat, {
                            conversacion: conversacion,
                            handleCloseCanvas: handleCloseCanvas
                        })
                    }, conversacion._id)
                )
            })
        ]
    }));
};
/* harmony default export */ const chats_MisChats = (MisChats);

;// CONCATENATED MODULE: ./src/components/ui/header/Header.tsx











const Header = ()=>{
    const { auth , logOut , abrirRegistro , abrirLogin , signOut  } = (0,external_react_.useContext)(AuthContext/* AuthContext */.V);
    const { chatState  } = (0,external_react_.useContext)(ChatContext/* ChatContext */.p5);
    const { 0: mostrarMenu , 1: setMostrarMenu  } = (0,external_react_.useState)(false);
    const target = (0,external_react_.useRef)(null);
    const cerrarSesion = ()=>{
        logOut();
        setMostrarMenu(false);
        chatState.chatActivo = null;
    };
    const { 0: showCanvas , 1: setShowCanvas  } = (0,external_react_.useState)(false);
    const handleCloseCanvas = ()=>setShowCanvas(false)
    ;
    const handleShowCanvas = ()=>setShowCanvas(true)
    ;
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)(external_react_bootstrap_.Navbar, {
        className: (Header_module_default()).navStyle,
        bg: "light",
        expand: "lg",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(external_react_bootstrap_.Container, {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "my-2",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                            href: "/",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                src: "/images/logos/red1-color.png",
                                alt: "Red 1 a 1",
                                className: "pointer"
                            })
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(external_react_bootstrap_.Navbar.Toggle, {
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(external_react_bootstrap_.Navbar.Collapse, {
                        children: !auth.logged ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)(external_react_bootstrap_.Nav, {
                            className: "ms-auto my-2",
                            navbarScroll: true,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    onClick: abrirRegistro,
                                    className: `${(Header_module_default()).navEnlace} pointer ms-3`,
                                    children: "Reg\xedstrate"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(Button/* default */.Z, {
                                    titulo: "Inicia sesi\xf3n",
                                    onClick: abrirLogin
                                })
                            ]
                        }) : /*#__PURE__*/ (0,jsx_runtime_.jsxs)(external_react_bootstrap_.Nav, {
                            className: "ms-auto my-2",
                            navbarScroll: true,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                    href: "/",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "pointer mx-4 d-flex align-items-center",
                                        children: "INICIO"
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(Button/* default */.Z, {
                                    titulo: "mis chats",
                                    onClick: handleShowCanvas
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: `${(Header_module_default()).navPerfil} pointer ms-3`,
                                    ref: target,
                                    onClick: ()=>setMostrarMenu(!mostrarMenu)
                                    ,
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                        src: auth.img,
                                        alt: "Mi perfil",
                                        style: {
                                            width: "100%",
                                            height: "100%",
                                            borderRadius: "50%"
                                        }
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(external_react_bootstrap_.Overlay, {
                                    target: target.current,
                                    show: mostrarMenu,
                                    placement: "right",
                                    children: ({ placement , arrowProps , show: _show , popper , ...props })=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: (Header_module_default()).menu,
                                            ...props,
                                            style: {
                                                ...props.style
                                            },
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                                    href: "/perfil",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                        className: `${(Header_module_default()).menuItem} pointer mx-3 my-2`,
                                                        onClick: ()=>{
                                                            setMostrarMenu(false);
                                                        },
                                                        children: "Mi Perfil"
                                                    })
                                                }),
                                                auth.role === "Individual" ? null : /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                                    href: "/perfil/mis-usuarios",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                        className: `${(Header_module_default()).menuItem} pointer mx-3 my-2`,
                                                        onClick: ()=>{
                                                            setMostrarMenu(false);
                                                        },
                                                        children: "Mis Usuarios"
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                                    href: "/perfil/mis-paquetes",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                        className: `${(Header_module_default()).menuItem} pointer mx-3 my-2`,
                                                        onClick: ()=>{
                                                            setMostrarMenu(false);
                                                        },
                                                        children: "Mis Paquetes"
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                                    href: "/perfil/historial-de-pagos",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                        className: `${(Header_module_default()).menuItem} pointer mx-3 my-2`,
                                                        onClick: ()=>{
                                                            setMostrarMenu(false);
                                                        },
                                                        children: "Mis Pagos"
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                    className: `${(Header_module_default()).menuCerrar} pointer mx-3 my-2`,
                                                    onClick: cerrarSesion,
                                                    children: "Cerrar sesion"
                                                })
                                            ]
                                        })
                                })
                            ]
                        })
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(authmodal_LoginModal, {
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(AuthModal/* default */.Z, {
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(chats_MisChats, {
                showCanvas: showCanvas,
                handleCloseCanvas: handleCloseCanvas
            })
        ]
    }));
};
/* harmony default export */ const header_Header = (Header);


/***/ }),

/***/ 6272:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ purpleheader_PurpleHeader)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./src/context/auth/AuthContext.tsx
var AuthContext = __webpack_require__(1165);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
// EXTERNAL MODULE: external "react-geosuggest"
var external_react_geosuggest_ = __webpack_require__(8580);
var external_react_geosuggest_default = /*#__PURE__*/__webpack_require__.n(external_react_geosuggest_);
// EXTERNAL MODULE: ./src/context/map/MapContext.tsx
var MapContext = __webpack_require__(1392);
// EXTERNAL MODULE: ./src/components/ui/buscador/Buscador.module.css
var Buscador_module = __webpack_require__(2893);
var Buscador_module_default = /*#__PURE__*/__webpack_require__.n(Buscador_module);
;// CONCATENATED MODULE: ./src/components/ui/buscador/Buscador.tsx






const Buscador = ()=>{
    const geosuggestEl = (0,external_react_.useRef)(null);
    const router = (0,router_.useRouter)();
    const { setCoordenadas , setDirMapa , setZoom  } = (0,external_react_.useContext)(MapContext/* MapContext */.X);
    const onSuggestSelect = (suggest)=>{
        !suggest ? setCoordenadas({
            lat: 19.4326077,
            lng: -99.133208
        }) : setCoordenadas({
            lat: suggest.location.lat,
            lng: suggest.location.lng
        });
        router.push("/");
        !suggest ? setDirMapa(null) : setDirMapa(suggest.label);
        !suggest ? setZoom(5) : setZoom(12);
    };
    return(/*#__PURE__*/ jsx_runtime_.jsx((external_react_geosuggest_default()), {
        ref: geosuggestEl,
        queryDelay: 530,
        country: "mx",
        placeholder: "Busca aqu\xed...",
        onSuggestSelect: onSuggestSelect,
        autoComplete: "off",
        inputClassName: (Buscador_module_default()).buscador,
        suggestsClassName: (Buscador_module_default()).respuesta,
        suggestItemClassName: (Buscador_module_default()).item
    }));
};
/* harmony default export */ const buscador_Buscador = (Buscador);

// EXTERNAL MODULE: ./src/components/ui/purpleheader/PurpleHeader.module.css
var PurpleHeader_module = __webpack_require__(7410);
var PurpleHeader_module_default = /*#__PURE__*/__webpack_require__.n(PurpleHeader_module);
;// CONCATENATED MODULE: ./src/components/ui/purpleheader/PurpleHeader.tsx






const PurpleHeader = ()=>{
    const { auth  } = (0,external_react_.useContext)(AuthContext/* AuthContext */.V);
    return(/*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: (PurpleHeader_module_default()).purpleNav2,
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
            className: "nav d-flex justify-content-center",
            children: [
                auth.uid ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                            className: "nav-item mt-2",
                            children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                href: "/perfil/mis-propiedades",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: `${(PurpleHeader_module_default()).purpleLinks} mx-3 pointer`,
                                    children: "Mis Propiedades"
                                })
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                            className: "nav-item mt-2",
                            children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                href: "/perfil/mis-favoritos",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: `${(PurpleHeader_module_default()).purpleLinks} mx-3 pointer`,
                                    children: "Mis Favoritos"
                                })
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                            className: "nav-item mt-2",
                            children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                href: "/perfil",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: `${(PurpleHeader_module_default()).purpleLinks} mx-3 pointer`,
                                    children: "Mi Cuenta"
                                })
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                            className: "nav-item mt-2",
                            children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                href: "/perfil/historial-de-inmueble",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: `${(PurpleHeader_module_default()).purpleLinks} mx-3 pointer`,
                                    children: "Historial de Inmuebles"
                                })
                            })
                        })
                    ]
                }) : null,
                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                    className: "nav-item",
                    children: /*#__PURE__*/ jsx_runtime_.jsx(buscador_Buscador, {
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                    children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                        className: (PurpleHeader_module_default()).searchBtn,
                        children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                            className: "bi bi-search"
                        })
                    })
                })
            ]
        })
    }));
};
/* harmony default export */ const purpleheader_PurpleHeader = (PurpleHeader);


/***/ }),

/***/ 1810:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "J": () => (/* binding */ SocketContext),
/* harmony export */   "w": () => (/* binding */ SocketProvider)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _hooks_useSocket__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5373);
/* harmony import */ var _auth_AuthContext__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1165);
/* harmony import */ var _chat_ChatContext__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1458);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_hooks_useSocket__WEBPACK_IMPORTED_MODULE_2__]);
_hooks_useSocket__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];





const SocketContext = /*#__PURE__*/ (0,react__WEBPACK_IMPORTED_MODULE_1__.createContext)({
});
const SocketProvider = ({ children  })=>{
    const { auth  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_auth_AuthContext__WEBPACK_IMPORTED_MODULE_3__/* .AuthContext */ .V);
    const { dispatch  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_chat_ChatContext__WEBPACK_IMPORTED_MODULE_4__/* .ChatContext */ .p5);
    const { socket , online , conectarSocket , desconectarSocket  } = (0,_hooks_useSocket__WEBPACK_IMPORTED_MODULE_2__/* .useSocket */ .s)("https://prueba-red1a1.herokuapp.com");
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (auth.logged) {
            conectarSocket();
        }
    }, [
        auth,
        conectarSocket
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (!auth.logged) {
            desconectarSocket();
        }
    }, [
        auth,
        desconectarSocket
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        socket === null || socket === void 0 ? void 0 : socket.on("mensaje-personal", (mensaje)=>{
            dispatch({
                type: "NuevoMensaje",
                payload: mensaje
            });
        });
    }, [
        socket,
        dispatch
    ]);
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(SocketContext.Provider, {
        value: {
            socket,
            online
        },
        children: children
    }));
};

});

/***/ }),

/***/ 3289:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "T": () => (/* binding */ publicadoHace),
/* harmony export */   "_": () => (/* binding */ horaMes)
/* harmony export */ });
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2245);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_0__);

const publicadoHace = (fecha)=>{
    const hoyMes = moment__WEBPACK_IMPORTED_MODULE_0___default()(fecha);
    return hoyMes.fromNow();
};
const horaMes = (fecha)=>{
    const hoyMes = moment__WEBPACK_IMPORTED_MODULE_0___default()(fecha);
    return hoyMes.format("HH:mm a - D/MM/YY");
};


/***/ }),

/***/ 5373:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "s": () => (/* binding */ useSocket)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var socket_io_client__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4612);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([socket_io_client__WEBPACK_IMPORTED_MODULE_1__]);
socket_io_client__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__)[0];


const useSocket = (serverPath)=>{
    const { 0: socket , 1: setSocket  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(undefined);
    const { 0: online , 1: setOnline  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const conectarSocket = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(()=>{
        const token = localStorage.getItem('token');
        const socketTemp = (0,socket_io_client__WEBPACK_IMPORTED_MODULE_1__.io)(serverPath, {
            transports: [
                'websocket'
            ],
            autoConnect: true,
            forceNew: true,
            query: {
                'x-token': token
            }
        });
        setSocket(socketTemp);
    }, [
        serverPath
    ]);
    const desconectarSocket = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(()=>{
        socket === null || socket === void 0 ? void 0 : socket.disconnect();
    }, [
        socket
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        setOnline(socket === null || socket === void 0 ? void 0 : socket.connected);
    }, [
        socket
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        socket === null || socket === void 0 ? void 0 : socket.on('connect', ()=>setOnline(true)
        );
    }, [
        socket
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        socket === null || socket === void 0 ? void 0 : socket.on('disconnect', ()=>setOnline(false)
        );
    }, [
        socket
    ]);
    return {
        socket,
        online,
        conectarSocket,
        desconectarSocket
    };
};

});

/***/ }),

/***/ 2957:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__) => {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var nextjs_progressbar__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8890);
/* harmony import */ var nextjs_progressbar__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(nextjs_progressbar__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2245);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var moment_locale_es__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8678);
/* harmony import */ var moment_locale_es__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(moment_locale_es__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _context_auth_AuthContext__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1165);
/* harmony import */ var _components_layout_Layout__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6323);
/* harmony import */ var _context_inmuebles_InmuebleContext__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(4549);
/* harmony import */ var _context_map_MapContext__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1392);
/* harmony import */ var _context_chat_ChatContext__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1458);
/* harmony import */ var _context_socket_SocketContext__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(1810);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_layout_Layout__WEBPACK_IMPORTED_MODULE_5__, _context_socket_SocketContext__WEBPACK_IMPORTED_MODULE_9__]);
([_components_layout_Layout__WEBPACK_IMPORTED_MODULE_5__, _context_socket_SocketContext__WEBPACK_IMPORTED_MODULE_9__] = __webpack_async_dependencies__.then ? await __webpack_async_dependencies__ : __webpack_async_dependencies__);












moment__WEBPACK_IMPORTED_MODULE_2___default().locale('es');
function MyApp({ Component , pageProps  }) {
    return(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_context_auth_AuthContext__WEBPACK_IMPORTED_MODULE_4__/* .AuthProvider */ .H, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_context_chat_ChatContext__WEBPACK_IMPORTED_MODULE_8__/* .ChatProvider */ .aM, {
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_context_socket_SocketContext__WEBPACK_IMPORTED_MODULE_9__/* .SocketProvider */ .w, {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((nextjs_progressbar__WEBPACK_IMPORTED_MODULE_1___default()), {
                        height: 6,
                        color: "#7149BC",
                        options: {
                            showSpinner: false
                        }
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_context_map_MapContext__WEBPACK_IMPORTED_MODULE_7__/* .MapProvider */ .I, {
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_layout_Layout__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_context_inmuebles_InmuebleContext__WEBPACK_IMPORTED_MODULE_6__/* .InmuebleProvider */ .K, {
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Component, {
                                    ...pageProps
                                })
                            })
                        })
                    })
                ]
            })
        })
    }));
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MyApp);

});

/***/ }),

/***/ 2245:
/***/ ((module) => {

"use strict";
module.exports = require("moment");

/***/ }),

/***/ 8678:
/***/ ((module) => {

"use strict";
module.exports = require("moment/locale/es");

/***/ }),

/***/ 562:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 4365:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-middleware-regex.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 1853:
/***/ ((module) => {

"use strict";
module.exports = require("next/router");

/***/ }),

/***/ 8890:
/***/ ((module) => {

"use strict";
module.exports = require("nextjs-progressbar");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 358:
/***/ ((module) => {

"use strict";
module.exports = require("react-bootstrap");

/***/ }),

/***/ 8580:
/***/ ((module) => {

"use strict";
module.exports = require("react-geosuggest");

/***/ }),

/***/ 67:
/***/ ((module) => {

"use strict";
module.exports = require("react-google-login");

/***/ }),

/***/ 1187:
/***/ ((module) => {

"use strict";
module.exports = require("react-toastify");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 4612:
/***/ ((module) => {

"use strict";
module.exports = import("socket.io-client");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [730,848,22,651,220,924,227,346,458,392], () => (__webpack_exec__(2957)));
module.exports = __webpack_exports__;

})();