export interface Location {
  lng: number;
  lat: number;
}
