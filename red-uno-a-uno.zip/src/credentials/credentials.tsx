export const production: string = "https://prueba-red1a1.herokuapp.com/api";
export const development: string = "http://localhost:8080/api";
